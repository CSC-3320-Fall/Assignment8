#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char compare(char*, char*);

int main()
{
  FILE* fp;

  char line[256];

  fp=fopen("4HKD.pdb", "r");
  while(fgets(line, sizeof(line), fp)!=NULL)
  {
  
    if(compare(line, "ATOM")=='t' | compare(line, "HETATM")=='t')
      printf("%s", line);
  }

}
char compare(char* strOne, char* strTwo)
{
  int x;
  for(x=0;x<strlen(strTwo);x++)
  {
    if(strOne[x]!=strTwo[x])
      return 'f';
  }
  return 't';
}
