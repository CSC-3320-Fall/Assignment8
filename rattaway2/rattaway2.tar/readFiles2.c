#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct rxyz {int residue; double x; double y; double z;};

char compare(char*, char*);
double getDistance(double, double, double, double, double,double);
struct rxyz readValue(char*, int, char*);

int main()
{
  FILE* fp;
  FILE* outfile;

  char line[256];
  double x0, y0, z0;
  struct rxyz current, previous;
  int linesprocessed;
  linesprocessed=0;
  fp=fopen("4HKD.pdb", "r");
  outfile=fopen("residues.txt", "w");

  while(fgets(line, sizeof(line), fp)!=NULL)
  {
  
      if((compare(line, "ATOM")=='t' | compare(line, "HETATM")=='t' ) & (compare(&line[13], "CA")=='t'))
      {
        linesprocessed++;
	current=readValue(line, 23, "%d");
        if(linesprocessed>1)
        {
          fprintf(outfile, "Residue %d, Residue %d, Distance %lf\n", previous.residue, current.residue, getDistance(current.x, previous.x, current.y, previous.y, current.z, previous.z));
        }
        previous=current;
      }
  }

  printf("Total Lines Processed: %d\n", linesprocessed);
  fclose(outfile);
  fclose(fp);
}
struct rxyz readValue(char* line, int position, char* fmt)
{
  struct rxyz d;
  sscanf(&line[position], "%d %lf %lf %lf", &d.residue, &d.x, &d.y, &d.z);
  return d;
}

double getDistance(double x0, double x1, double y0, double y1, double z0, double z1)
{
  return sqrt(pow((x0-x1),2.0) + pow((y0-y1),2.0) + pow((z0-z1),2.0));
}

char compare(char* strOne, char* strTwo)
{
  int x;
  for(x=0;x<strlen(strTwo);x++)
  {
    if(strOne[x]!=strTwo[x])
      return 'f';
  }
  return 't';
}
