
/* Michael Amadasun
 * Datte: 11/5/2013
 * Assignment 8_1
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char filename[256];

    printf("What file would you like to read?\n");
    scanf("%s", &filename);

    FILE *file = fopen(filename, "r");

    if(file == NULL)
        printf("File does not exist");

    findstring(file, "ATOM", "HETATM");

    return 0;
}

int findstring(FILE *filep, char *str, char *str1){
    char word[10];
    int nl = 1;
    int finda = 0;
    int findh = 0;

    while(fgets(word, 10, filep) != NULL) {
		if((strstr(word, str)) != NULL) {
			finda++;
		}
		if((strstr(word, str1)) != NULL) {
			findh++;
		}
		nl++;
	}
    printf("The Occurence of the word ATOM in the file is: %d\n", finda);
    printf("The Occurence of the word HETATM in the file is: %d\n", findh);
    fclose(filep);
}

