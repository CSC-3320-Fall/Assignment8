/* Michael Amadasun
 * Datete: 11/5/2013
 * Assignment 8_2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char filename[256];

    printf("What file would you like to read?\n");
    scanf("%s", &filename);

    FILE *file = fopen(filename, "r");

    if(file == NULL)
        printf("File does not exist");

    findstring(file, "ATOM", "HETATM");

    return 0;
}

int findstring(FILE *filep, char *str, char *str1){
    char word[10];
    char CAp[] = "CA";
    int nl = 1;

    while(fgets(word, 10, filep) != NULL) {
		if((strstr(word, str)) != NULL) {
			if((strstr(word, CAp)) != NULL) {
                nl++;
			}
		}
		if((strstr(word, str1)) != NULL) {
            if((strstr(word, CAp)) != NULL) {
                nl++;
			}
		}

	}
    printf("The distance between each CA occurence is: %d\n", nl);
    fclose(filep);
}

