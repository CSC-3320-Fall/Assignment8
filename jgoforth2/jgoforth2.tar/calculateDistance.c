/* This is a program that will accept a file from cl. It will then open 
 * the file and will find the CA atom records and then store thier x, y, z
 * values and calculate the distance between the last two CA records found.
 * It will then print the two residue numbers and the distance between
 * them seperated by commas in a CSV file
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

int main(int argc, char **argv) 
{
	// Make sure that there is more than one argument
	if (argc != 2) {
		printf ("Usage is: \n inputFile\n");
		return 1;
	}
	// Create a variable to hold the file to be opened
	FILE *fp, *op;

	// Open the file given from  the command line
	fp = fopen(argv[1], "r");
	
	// Open file to write data to
	op = fopen("CA_distances.csv", "w");
	
	// Check to make sure file was opened
	if (fp == NULL) {
		printf("Cannot open %s\n", argv[1]);
	 	return 1;
	}
	else {
		printf("File %s opened successfully\n", argv[1]);
	}
	
	// Create variable to hold read string
	char str[100];
	
	// Create variables to hold strings we are looking for
	char *atom = "ATOM";
	char *hetatm = "HETATM";	
	char *ca_atom = "CA";
		
	// Create variables to hold residue number and x, y, z values
	int residue_num = 0;
	float x = 0, y = 0, z = 0; 
	
	// Read lines of input from file 
	while (fgets(str, sizeof(str), fp) != (char *)0)
	{
		// Create variable to hold first string
		char first_word[100];
		char atom_name[20];
		
		int temp_res_num = 0;
		float temp_x = 0, temp_y = 0, temp_z = 0;
		double distance = 0, temp = 0;
			
		// Read the first string in the file
		sscanf(str, "%s", first_word);
		if (strcmp(atom, first_word) == 0) {
			
			// Read the atom name
			sscanf(&str[13], "%s", atom_name);
			
			// See if record is CA
			if (strcmp(ca_atom, atom_name) == 0) {
			
				// See if first iteration
				if (residue_num == 0) {
					
					// Scan first set of numbers
					sscanf(&str[23],"%d%f%f%f", &residue_num, &x, &y, &z);
				}
				else {
				
					// Scan next set of digits
					sscanf(&str[23],"%d%f%f%f", &temp_res_num, &temp_x, &temp_y, &temp_z);
					
					// Find distance between the atoms
					distance = pow((temp_x - x), 2) + pow((temp_y - y), 2) + pow((temp_z - z), 2);
					
					distance = sqrt(distance);

					// Print the distance between the atoms
					fprintf(op, "%d,%d,%f\n", residue_num, temp_res_num, distance);
				
					// Change the number set to next record
					sscanf(&str[23],"%d%f%f%f", &residue_num, &x, &y, &z);
				}
			}
		}
		if (strcmp(hetatm, first_word) == 0) {
			sscanf(&str[13], "%s", atom_name);
			
			// See if record is CA
			if (strcmp(ca_atom, atom_name) == 0) {
				sscanf(&str[23],"%d", &residue_num);
					
				// Scan next set of digits
				sscanf(&str[23],"%d%f%f%f", &temp_res_num, &temp_x, &temp_y, &temp_z);
					
				// Find distance between the atoms
				distance = pow((temp_x - x), 2) + pow((temp_y - y), 2) + pow((temp_z - z), 2);
			
				distance = sqrt(distance);
				
				// Print the distance between the atoms
				fprintf(op, "%d,%d,%2.4f\n", residue_num, temp_res_num, distance);
			
				// Change the number set to next record
				sscanf(&str[23],"%d%f%f%f", &residue_num, &x, &y, &z);
					
			}
		}	
	}
	// Close the input file
	fclose(fp);
	// Close output file
	fclose(op);
	printf("File %s closed successfully\n", argv[1]);
		
	return 0;
}
