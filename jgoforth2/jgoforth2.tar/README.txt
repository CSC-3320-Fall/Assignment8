Please use the following two commands to get the desired answer for question one.
	cc -o countLines countLines.c 
	./countLines 4HKD.pdb
	
Please use the following two commands to get the desired answer for question two.
	cc -o calculateDistance calculateDistance.c -lm 
	./calculateDistance 4HKD.pdb

Do take note that I had to end up using the -lm flag for cc because of some linking errors
from the math library. These seemed to be caused by the sqrt() reference in calculateDistance.c and if -lm is not used the code will not compile.	