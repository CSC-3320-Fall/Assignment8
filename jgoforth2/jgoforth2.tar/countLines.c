/* This is a program that will accept a file. It will then open 
 * the file and count the number of lines begining with 'ATOM' and 'HETATM'
 * and then print the results on the console.
 */

#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) 
{
	// Make sure that there is more than one argument
	if (argc != 2) {
		printf ("Usage is: \n inputFile\n");
		return 1;
	}
	// Create a variable to hold the file to be opened
	FILE *fp;
	
	// Open the file given from the command line
	fp = fopen(argv[1], "r");
	
	// Check to make sure file was opened
	if (fp == NULL) {
		printf("Cannot open %s\n", argv[1]);
	 	return 1;
	}
	else {
		printf("File %s opened successfully\n", argv[1]);
	}
	
	// Create variable to hold read string
	char str[100];

	// Create a varible to count the line numbers
	int line_count = 0;
	
	// Create variables to hold strings we are looking for
	char *atom = "ATOM";
	char *hetatm = "HETATM";	
	// Read lines of input from file 
	while (fgets(str, sizeof(str), fp) != (char *)0)
	{
		// Create variable to hold first string
		char first_word[100];
		
		// Read the first string in the file
		sscanf(str, "%s", first_word);
		if (strcmp(atom, first_word) == 0) {
			line_count++;
		}
		if (strcmp(hetatm, first_word) == 0) {
			line_count++;
		}	
	}
	// Close the input file
	fclose(fp);

	// Print number of lines 
	printf("%d lines counted\n", line_count);
	return 0;
}
